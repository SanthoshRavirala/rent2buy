<meta property="og:url"           content="<?php echo $fb_url;?>" />
<meta property="og:type"          content="<?php echo $fb_type;?>" />
<meta property="og:title"         content="<?php echo $fb_title;?>" />
<meta property="og:description"   content="<?php echo $fb_description;?>" />
<meta property="og:image"         content="<?php echo $fb_image;?>" />
<?php if($fb_api){ ?>
<meta property="fb:app_id"        content="<?php echo $fb_api;?>" />
<?php } ?>
