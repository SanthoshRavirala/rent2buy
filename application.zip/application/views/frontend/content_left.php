<?php 
foreach($_extensions['left'] as $extension){
	echo $extension;
}        
	