<?php 
foreach($_extensions['top'] as $extension){
	echo $extension;
}        
	