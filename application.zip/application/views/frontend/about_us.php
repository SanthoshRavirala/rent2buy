  <div class="ppb_wrapper  ">
            <div class="one withsmallpadding ppb_header_youtube withbg parallax" data-jarallax-video="https://www.youtube.com/watch?v=Mz5PAKmwAqc" style="text-align:center;padding:305px 0 305px 0;color:#ffffff;">
                <div class="overlay_background" style="background:#000000;background:rgb(0,0,0,0.5);background:rgba(0,0,0,0.5);"></div>
                <div class="standard_wrapper">
                    <div class="page_content_wrapper">
                        <div class="inner">
                            <div style="margin:auto;width:60%">
                                <h2 class="ppb_title" style="color:#ffffff;">We are Grand Car Rental Best Car Rental WordPress Theme</h2>
                                <div class="page_tagline" style="color:#ffffff;">Car rental, limousine, and car hire. All in one service.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="one withsmallpadding ppb_header " style="text-align:center;padding:50px 0 50px 0;background-color:#5856d6;color:#ffffff;">
                <div class="standard_wrapper">
                    <div class="page_content_wrapper">
                        <div class="inner">
                            <div style="margin:auto;width:50%">
                                <h2 class="ppb_title" style="color:#ffffff;">This adventure isn’t about change but it seems to be an inevitability.</h2>
                                <div class="ppb_header_content">
                                    <p>Meh synth Schlitz, tempor duis single-origin coffee ea next level ethnic fingerstache fanny pack nostrud.Photo booth anim 8-bit hella, PBR 3 wolf moon beard Helvetica. Salvia esse nihil, flexitarian Truffaut synth art party deep v chillwave. Seitan High Life reprehenderit consectetur cupidatat kogi. Et leggings fanny pack, elit bespoke vinyl art party Pitchfork selfies master cleanse.</p>
                                    <p> </p>
                                    <div class="one_half " style="">
                                        <div class="animate_counter_wrapper">
                                            <div id="15722574381434579802" class="odometer" style="font-size:60px;line-height:60px;">0</div>
                                            <div class="count_separator"><span></span></div>
                                            <div class="counter_subject">Trips</div>
                                        </div>
                                    </div>
                                    <div class="one_half last " style="">
                                        <div class="animate_counter_wrapper">
                                            <div id="15722574381897655566" class="odometer" style="font-size:60px;line-height:60px;">0</div>
                                            <div class="count_separator"><span></span></div>
                                            <div class="counter_subject">Happy Customers</div>
                                        </div>
                                    </div>
                                    <p>
                                        <br class="clear" />
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="one withsmallpadding ppb_contact_half_bg withbg parallax " style="background-image:url(<?php echo base_url('template/');?>upload/evening.jpg);background-position: center center;padding:40px 0 40px 0;">
                <div class="standard_wrapper">
                    <div class="page_content_wrapper">
                        <div class="inner">
                            <div class="one_half_bg" style="background:#000000;background:rgb(0,0,0,0.8);background:rgba(0,0,0,0.8);color:#ffffff;" data-stellar-ratio="1.3">
                                <h2 class="ppb_title" style="color:#ffffff;">Get In Touch With Us</h2>
                                <div class="page_tagline" style="color:#ffffff;">This is sample of sub title.</div>
                                <div class="contact_form7_wrapper">
                                    <div role="form" class="wpcf7" id="wpcf7-f2465-o1" lang="en-US" dir="ltr">
                                        <div class="screen-reader-response"></div>
                                        <form action="<?php echo base_url('home/contact_submit');?>" method="POST" class="wpcf7-form" >

                                            <p>
                                                <label> Your Name*
                                                    <br />
                                                    <span class="wpcf7-form-control-wrap your-name"><input type="text" required name="name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span> </label>
                                            </p>
                                            <p>
                                                <label> Your Emai*
                                                    <br />
                                                    <span class="wpcf7-form-control-wrap your-email"><input type="email"  required name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" /></span> </label>
                                            </p>
                                            <p>
                                                <label> Subject
                                                    <br />
                                                    <span class="wpcf7-form-control-wrap your-subject"><input type="text" required name="subject" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" /></span> </label>
                                            </p>
                                            <p>
                                                <label> Your Message
                                                    <br />
                                                    <span class="wpcf7-form-control-wrap your-message"><textarea name="message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span> </label>
                                            </p>
                                            <p>
                                                <input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" />
                                            </p>
                                            <div class="wpcf7-response-output wpcf7-display-none"></div>
											<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                            <input type="hidden" name="<?php echo 'form_type'; ?>" value="<?php echo 'About us'; ?>">
 
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>