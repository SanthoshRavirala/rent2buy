<div id="page_caption" class="hasbg parallax  withtopbar  " style="background-image:url(<?=base_url('template/')?>upload/driver-2.jpg); ">

            <div class="page_title_wrapper">
                <div class="page_title_inner">
                    <div class="page_title_content">
                        <h1 class="withtopbar">Thank you</h1>
                        <!--div class="page_tagline">
                            We will contact with you soo</div-->
                    </div>
                </div>
            </div>

        </div>

        <div class="ppb_wrapper hasbg withtopbar">
            <div class="one withsmallpadding ppb_text" style="text-align:left;padding:40px 0 40px 0;">
                <div class="standard_wrapper">
                    <div class="page_content_wrapper">
                        <div class="inner">
                            <div style="margin-top:-100px;width:100% text-align:center;"  class="text-center">
                                <p >
								<center>
								<img src="<?=base_url();?>uploads/check_mark.png" style="width:15%;">
							</center>	
                                    <div id="1572257586561081791" class="alert_box success"><i class="fa fa-bullhorn alert_icon"></i>
                                        <div class="alert_box_msg">We will contact with you soo</div><a href="#" class="close_alert" data-target="1572257586561081791"><i class="fa fa-times"></i></a></div>
                                    <br />
                                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="divider one">&nbsp;</div>
            <div class="divider one">&nbsp;</div>
        </div>
