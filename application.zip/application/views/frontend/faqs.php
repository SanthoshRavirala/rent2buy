<div id="page_caption" class="hasbg parallax  withtopbar  " style="background-image:url(<?=base_url('template/')?>upload/driver-2.jpg);">

            <div class="page_title_wrapper">
                <div class="page_title_inner">
                    <div class="page_title_content">
                        <h1 class="withtopbar">FAQs</h1>
                        <div class="page_tagline">
                            This is sample of page tagline and you can set it up using page option </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Begin content -->
        <div id="page_content_wrapper" class="hasbg withtopbar ">
            <div class="inner">

                <!-- Begin main content -->
                <div class="inner_wrapper">

                    <div class="sidebar_content full_width nopadding">
                        <div class="sidebar_content page_content">
                            <h3>Payment</h3>
                            <div class="pp_accordion_close has_icon">
                                <h3><a href="#">Are there any extra fees that I will have to pay on top of the listed price?</a></h3>
                                <div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam.</p>
                                </div>
                            </div>
                            <div class="pp_accordion_close has_icon">
                                <h3><a href="#">Should I print a receipt to show when I arrive?</a></h3>
                                <div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam.</p>
                                </div>
                            </div>
                            <div class="pp_accordion_close has_icon">
                                <h3><a href="#">How much does it cost to do a private limousine?</a></h3>
                                <div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam.</p>
                                </div>
                            </div>
                            <p>&nbsp;</p>
                            <h3>Preparation</h3>
                            <div class="pp_accordion_close has_icon">
                                <h3><a href="#">What should I wear?</a></h3>
                                <div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam.</p>
                                </div>
                            </div>
                            <div class="pp_accordion_close has_icon">
                                <h3><a href="#">What do I need to bring?</a></h3>
                                <div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam.</p>
                                </div>
                            </div>
                            <div class="pp_accordion_close has_icon">
                                <h3><a href="#">How much does it cost to do a private limousine?</a></h3>
                                <div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam.</p>
                                </div>
                            </div>
                            <p>&nbsp;</p>
                            <h3>Reservation</h3>
                            <div class="pp_accordion_close has_icon">
                                <h3><a href="#">What is your refund policy?</a></h3>
                                <div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam.</p>
                                </div>
                            </div>
                            <div class="pp_accordion_close has_icon">
                                <h3><a href="#">Do you offer 30 days money back guarantee?</a></h3>
                                <div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam.</p>
                                </div>
                            </div>
                            <div class="pp_accordion_close has_icon">
                                <h3><a href="#">Do I have to make a reservation?</a></h3>
                                <div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam. Lorem ipsum dosectetur adipisicing elit, sed do.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labolore magna aliqua. Ut enim ad minim veniam.</p>
                                </div>
                            </div>

                        </div>

                        <div class="sidebar_wrapper">
                            <div class="sidebar">

                                <div class="content">

                                    <ul class="sidebar_widget">
                                        <li id="text-5" class="widget widget_text">
                                            <h2 class="widgettitle">Can&#8217;t Find Answer? Ask Us</h2>
                                            <div class="textwidget">
                                                <div role="form" class="wpcf7" id="wpcf7-f2465-o1" lang="en-US" dir="ltr">
                                                    <div class="screen-reader-response"></div>
                                                    <form action="<?php echo base_url('home/contact_submit');?>" method="POST" class="wpcf7-form" >

                                                        <p>
                                                            <label> Your Name*
                                                                <br />
                                                                <span class="wpcf7-form-control-wrap your-name"><input type="text" required name="name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span> </label>
                                                        </p>
                                                        <p>
                                                            <label> Your Emai*
                                                                <br />
                                                                <span class="wpcf7-form-control-wrap your-email"><input type="email" required name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" /></span> </label>
                                                        </p>
                                                        <p>
                                                            <label> Subject
                                                                <br />
                                                                <span class="wpcf7-form-control-wrap your-subject"><input type="text" required name="subject" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" /></span> </label>
                                                        </p>
                                                        <p>
                                                            <label> Your Message
                                                                <br />
                                                                <span class="wpcf7-form-control-wrap your-message"><textarea name="message"  required cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span> </label>
                                                        </p>
                                                        <p>
                                                            <input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" />
                                                        </p>
                                                        <div class="wpcf7-response-output wpcf7-display-none"></div>
														<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                                        <input type="hidden" name="<?php echo 'form_type'; ?>" value="<?php echo 'FAQs'; ?>">
                                                    </form>
                                                </div>
                                            </div>
                                        </li>
                                        <li id="text-6" class="widget widget_text">
                                            <h2 class="widgettitle">For More Informations</h2>
                                            <div class="textwidget">
                                                <p><span class="ti-mobile" style="margin-right:10px;"></span>1-567-124-44227
                                                    <br />
                                                    <br />
                                                    <span class="ti-alarm-clock" style="margin-right:10px;"></span>Mon - Sat 8.00 - 18.00</p>
                                            </div>
                                        </li>
                                    </ul>

                                </div>

                            </div>
                            <br class="clear" />
                        </div>
                    </div>

                </div>
                <!-- End main content -->
            </div>
        </div>
		
		
		
		
 

    
