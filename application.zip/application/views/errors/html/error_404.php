<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php echo $header;?>
		<h1><?php echo $heading; ?></h1>
		<?php echo $message; ?>
</body>
</html>