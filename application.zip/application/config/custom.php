<?php
$config['c_sitename']     = 'User management';
$config['c_description']  = 'User management system';
$config['c_keyword']      = 'User management';
$config['c_author']       = 'User management - php script';
$config['c_tag']          = 'User management,php script';
$config['c_image_path']   = '';
$config['c_default_group']   = '1';
$config['c_limit']        = '5';
$config['c_fb_enabled']   = '1';
$config['c_ga_code']      = '';
$config['c_empty_region'] = '0';
$config['c_empty_nation'] = '1';
$config['c_empty_age']    = '1';
$config['c_gender_results'] = '0';