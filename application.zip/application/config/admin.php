<?php
$config['admin_name']     = '<b>User management</b>';
$config['admin_short_name']     = '<b>UM</b>';

