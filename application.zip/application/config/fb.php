<?php
$config['fb_title']        = 'Poll system';
$config['fb_description']  = 'Vote for favorite option';
$config['fb_image']        = 'assets/logo.png';
$config['fb_type']         = 'website';
$config['fb_url']          = '';
$config['fb_api']          = '';