<?php
$lang['text_title'] 		= "Home";
$lang['text_register'] 		= "Register";
$lang['text_login'] 		= "login";
