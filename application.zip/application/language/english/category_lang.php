<?php
$lang['text_description']	  = "This is example data for category.";
$lang['text_must_login']	  = "You must login";
$lang['text_only_once']	      = "You can vote only once for this poll";
$lang['text_closed']	      = "Closed for voting";
$lang['text_first']	          = "Be first to vote";
$lang['text_vote']	          = "Vote";
$lang['text_view_results']	  = "Results";


