<?php
$lang['error_name']			    = "Enter name";
$lang['error_code']			    = "Enter code";
