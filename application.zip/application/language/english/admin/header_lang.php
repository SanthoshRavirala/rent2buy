<?php
$lang['text_logout'] 	= "Logout";
$lang['text_home'] 	    = "Home";
