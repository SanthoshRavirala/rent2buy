<?php
$lang['global_error']            = "Wrong login details";
$lang['text_alert']	             = "Alert!";