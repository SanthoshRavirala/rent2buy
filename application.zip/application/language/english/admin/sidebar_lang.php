<?php                     
$lang['text_dashboard']   = "Dashboard";
$lang['text_navigation']  = "Navigation";
$lang['text_category']    = "Categories";
$lang['text_user']        = "Users";
$lang['text_user_group']  = "User groups";
$lang['text_region']      = "Regions";
$lang['text_nation']      = "Nations";
$lang['text_language']    = "Languages";
$lang['text_part']        = "layouts";
$lang['text_extension']   = "Extensions";