<?php
$lang['text_title']			 = "Login";
$lang['text_email']			 = "Email";
$lang['text_password']		 = "Password";
$lang['text_admin']		     = "Admin sign in";
$lang['text_sign_in']		 = "Sign in";
$lang['text_remember']		 = "Remember me";
