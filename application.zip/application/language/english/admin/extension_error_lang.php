<?php
$lang['error_name']			    = "Enter name";
$lang['error_path']			    = "Enter page for extension ( Ex. home)";
$lang['error_part']			    = "Enter layout( left,top,footer ...)";

