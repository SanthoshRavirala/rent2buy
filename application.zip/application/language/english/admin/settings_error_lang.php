<?php
$lang['error_name']			    = "Enter name";
