<?php
$lang['text_title']			    = "Language";
$lang['text_name']	            = "Name";
$lang['text_code']			    = "Code";
$lang['text_id']			    = "ID";
$lang['text_edit_delete']	    = "Edit/Delete";
$lang['text_add']	            = "Add";
$lang['text_edit']	            = "Edit";
$lang['text_showing']		    = "Showing %s to %s from %s items";
