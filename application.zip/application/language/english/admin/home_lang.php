<?php
$lang['text_dashboard']   = "Dashboard";
$lang['text_title'] 	  = "Home";
$lang['text_users'] 	  = "Total users";
$lang['text_nations']     = "Nations";
$lang['text_languages']   = "Languages";
$lang['text_regions'] 	  = "Total regions";
