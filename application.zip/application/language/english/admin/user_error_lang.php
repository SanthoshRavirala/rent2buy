<?php
$lang['error_firstname']	     = "Enter firstname";
$lang['error_lastname']	         = "Enter lastname";
$lang['error_email']	         = "Enter email";
$lang['error_password']	         = "Enter password";
$lang['error_date_birth']	     = "Enter date";
$lang['error_nation']	         = "Select nation";
$lang['error_region']	         = "Slect region";
$lang['error_gender']	         = "Select gender";
$lang['error_exists']	         = "This email already exists";