<?php
$lang['text_title'] 	    = "Confirm";
$lang['text_close'] 	    = "Close";
$lang['text_delete'] 	    = "Delete";
$lang['text_body'] 	        = "Are you sure?";
