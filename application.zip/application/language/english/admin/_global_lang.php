<?php
$lang['button_cancel']	            = "Cancel";
$lang['text_cancel']	            = "Cancel";
$lang['button_add']	                = "Add";
$lang['button_edit']	            = "Edit";
$lang['button_ok']	                = "Ok";
$lang['text_all']	                = "All";
$lang['text_more']	                = "More";
$lang['text_no']	                = "No";
$lang['text_yes']	                = "Yes";
$lang['text_no_results']            = "No result";
