<?php
$lang['text_title']			 = "Nations";
$lang['text_name']	         = "Name";
$lang['text_priority']	     = "Priority";
$lang['text_type']	         = "Type";
$lang['text_select_type']	 = "Select";
$lang['text_id']			 = "ID";
$lang['text_edit_delete']	 = "Edit/Delete";
$lang['text_add']	         = "Add";
$lang['text_edit']	         = "Edit";
$lang['text_showing']		 = "Showing %s to %s from %s items";

