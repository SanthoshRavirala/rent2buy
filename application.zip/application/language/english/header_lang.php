<?php
$lang['text_register'] 	= "Register";
$lang['text_login'] 	= "Login";
$lang['text_logout'] 	= "Logout";
$lang['text_home']   	= "Home";
