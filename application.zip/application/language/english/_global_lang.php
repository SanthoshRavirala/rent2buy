<?php
$lang['button_cancel']	            = "Cancel";
$lang['button_add']	                = "Add";
$lang['button_edit']	            = "Edit";
$lang['button_ok']	                = "Ok";
$lang['text_all']	                = "All";

