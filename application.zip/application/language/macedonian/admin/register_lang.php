<?php
$lang['text_title']			 = "Најава";

$lang['text_email']			 = "Емаил";
$lang['text_password']		 = "Лозинка";

$lang['text_admin']		     = "Администраторски дел";
$lang['text_sign_in']		 = "Најава";
$lang['text_remember']		 = "Запомни ме";



