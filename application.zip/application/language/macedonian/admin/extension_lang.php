<?php
$lang['text_title']			 = "Модули";
$lang['text_name']	         = "Име";
$lang['text_path']	         = "Страница";
$lang['text_part']	         = "Блок";
$lang['text_status']	     = "Статус";
$lang['text_priority']	     = "Позиција";
$lang['text_type']	         = "Тип";
$lang['text_select_part']	 = "Избери";
$lang['text_id']			 = "ID";
$lang['text_edit_delete']	 = "Смени/Бриши";
$lang['text_add']	    	 = "Додај модул";
$lang['text_edit']	    	 = "Смени модул";
$lang['text_showing']		 = "Showing %s to %s of %s entries";

