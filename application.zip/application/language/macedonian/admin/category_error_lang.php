<?php
$lang['error_name']			    = "Внесете име";
