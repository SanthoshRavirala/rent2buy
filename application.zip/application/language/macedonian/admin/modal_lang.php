<?php
$lang['text_title'] 	    = "Конфирмација";
$lang['text_close'] 	    = "Откажи";
$lang['text_delete'] 	    = "Избриши";
$lang['text_body'] 	        = "Дали сте сигурни";



