<?php
$lang['text_title']			 = "Нации";
$lang['text_name']	         = "Име";
$lang['text_priority']	     = "Позиција";
$lang['text_type']	         = "Тип";
$lang['text_select_type']	 = "Избери";
$lang['text_id']			 = "ID";
$lang['text_edit_delete']	 = "Смени/Бриши";
$lang['text_add']	    	 = "Додај нација";
$lang['text_edit']	    	 = "Смени смени";
$lang['text_showing']		    = "Прикажани %s до %s од %s ставки";

