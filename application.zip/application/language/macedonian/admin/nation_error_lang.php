<?php
$lang['error_name']			    = "Внесете име";
$lang['error_type']			    = "Изберете тип";
