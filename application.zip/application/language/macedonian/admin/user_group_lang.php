<?php
$lang['text_title']			    = "Групи";
$lang['text_name']	            = "Име";
$lang['text_id']			    = "ID";
$lang['text_edit_delete']	    = "Смени/Бриши";
$lang['text_add']	    		= "Додај";
$lang['text_edit']	    		= "Смени";
$lang['error_name']			    = "Внесете име";
$lang['text_showing']		    = "Прикажани %s до %s од %s ставки";

