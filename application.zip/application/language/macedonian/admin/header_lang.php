<?php
$lang['text_logout'] 	= "Одјава";
$lang['text_home'] 	    = "Почетна";
