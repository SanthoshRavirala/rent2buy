<?php
$lang['text_dashboard']   = "Работна површина";
$lang['text_title'] 	  = "Почетна";
$lang['text_users'] 	  = "Вкупно корисници";
$lang['text_nations']     = "Нации";
$lang['text_languages']   = "Јазици";
$lang['text_regions'] 	  = "Вкупно региони";
