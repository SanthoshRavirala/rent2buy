<?php
$lang['text_dashboard']  = "Работна површина";
$lang['text_navigation'] = "Навигација";
$lang['text_poll']       = "Анкети";
$lang['text_category']   = "Категории";
$lang['text_user']       = "Корисници";
$lang['text_user_group'] = "Кориснички групи";
$lang['text_region']     = "Региони";
$lang['text_nation']     = "Нации";
$lang['text_language']   = "Јазици";
$lang['text_part']       = "Делови";
$lang['text_extension']  = "Модули";