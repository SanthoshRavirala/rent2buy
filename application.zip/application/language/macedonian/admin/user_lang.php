<?php
$lang['text_title']			 = "Регистрација";
$lang['text_form']			 = "Форма за регистрација";
$lang['text_firstname']	     = "Име";
$lang['text_lastname']		 = "Презиме";
$lang['text_email']			 = "Емаил";
$lang['text_password']		 = "Лозинка";
$lang['text_region']		 = "Регион";
$lang['text_select_region']	 = "Изберете регион";
$lang['text_nation']		 = "Националност";
$lang['text_select_nation']	 = "Изберете националност";
$lang['text_user_group']	 = "Група";
$lang['text_gender']		 = "Пол";
$lang['text_date_birth']	 = "Дата на раѓање";
$lang['text_male']		     = "Машки";

$lang['text_female']		 = "Женски";
$lang['text_id']		     = "ID";
$lang['text_edit_delete']	 = "Смени/Избриши";
$lang['text_add']	 = "Додај";
$lang['text_edit']	 = "Смени";
$lang['text_showing']		    = "Прикажани %s до %s од %s ставки";
 
