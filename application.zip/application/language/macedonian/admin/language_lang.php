<?php
$lang['text_title']			    = "Јазици";
$lang['text_name']	            = "Име";
$lang['text_code']			    = "Код";
$lang['text_id']			    = "ID";
$lang['text_edit_delete']	    = "Смени/Бриши";
$lang['text_add']	    		= "Додај јазик";
$lang['text_edit']	    		= "Смени јазик";
$lang['error_name']			    = "Внесете име";
$lang['text_showing']		    = "Прикажани %s до %s од %s ставки";

