<?php
$lang['text_title']			    = "Категории";
$lang['text_name']	            = "Име";
$lang['text_priority']	        = "Позиција";
$lang['text_id']			    = "ID";
$lang['text_edit_delete']	    = "Смени/Бриши";
$lang['text_add']	    		= "Додај категорија";
$lang['text_edit']	    		= "Смени категорија";
$lang['text_showing']		    = "Прикажани %s до %s од %s ставки";

