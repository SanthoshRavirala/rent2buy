<?php
$lang['button_cancel']	            = "Откажи";
$lang['button_add']	                = "Додај";
$lang['button_edit']	            = "Смени";
$lang['button_ok']	                = "Ok";
$lang['text_all']	                = "Сите";
$lang['text_more']	                = "Повеќе";
$lang['text_no']	                = "Не";
$lang['text_yes']	                = "Да";
$lang['text_no_results']            = "Нема резултати";

