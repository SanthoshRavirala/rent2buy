<?php
$lang['text_description']	  = "Пример за категорија";
$lang['text_must_login']	  = "Мора да се логирате";
$lang['text_only_once']	      = "Можете да гласате само еднаш";
$lang['text_closed']	      = "Затворена анкета";
$lang['text_first']	          = "Бидете прв што ќе гласа";
$lang['text_vote']	          = "Гласај";
$lang['text_view_results']	  = "Резултати";


