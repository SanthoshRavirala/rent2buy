<?php
$lang['text_description'] = "This is example data loaded from latest module. Use it as a starting point to create something more unique.";

