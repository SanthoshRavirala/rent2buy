<?php
$lang['text_title']	             = "Листа на анкети";

 
