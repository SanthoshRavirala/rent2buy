<?php
$lang['text_register'] 	= "Регистрација";
$lang['text_login'] 	= "Најава";
$lang['text_logout'] 	= "Одјава";
$lang['text_home']   	= "Почетна";
