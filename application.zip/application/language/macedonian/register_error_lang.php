<?php
$lang['global_error']            = "Внесениот емаил и лозинка не се совпаѓаат";
$lang['text_alert']	             = "Алерт!";
$lang['error_firstname']	     = "Внесете име";
$lang['error_lastname']	         = "Внесете презиме";
$lang['error_email']	         = "Внесете емаил";
$lang['error_password']	         = "Внесете лозинка";
$lang['error_date_birth']	     = "Внесете датум на раѓање";
$lang['error_nation']	         = "Изберете националност";
$lang['error_region']	         = "Изберете регион";
$lang['error_gender']	         = "Изберете пол";
$lang['error_exists']	         = "Внесениот емаил веќе постои во нашата база";
