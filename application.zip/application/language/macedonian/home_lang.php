<?php
$lang['text_title'] 		= "Почетна";
